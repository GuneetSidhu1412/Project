# Deploy sample Application to AKS Cluster

This lab is to deploy the sample Application to AKS cluster

The purpose of this lab is to deploy the sample Application to AKS cluster. 

In this lab, you will:
- Update terraform with AKS ACR role assignment
- Deploy Application Insights using terraform
- Deploy Azure Key Vault using Terraform
- Update Azure DevOps pipeline and Deploy sample application to AKS!
